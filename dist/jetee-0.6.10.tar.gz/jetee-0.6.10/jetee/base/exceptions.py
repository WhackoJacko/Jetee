class ImproperlyConfigured(Exception):
    pass