REQUIRED_ANSIBLE_ROLES = (
    u'jdauphant.nginx',
    u'EDITD.supervisor_task,v0.6',
    u'DavidWittman.redis'
)